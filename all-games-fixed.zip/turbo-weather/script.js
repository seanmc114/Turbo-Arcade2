

// --- Verb data (FULL SUPER verb set for Present, Past, and Future) ---
const VERB_SETS = {
  "Present": [
    {
      "en": "It is cold",
      "es": "hace frio"
    },
    {
      "en": "It is very cold",
      "es": "hace mucho frio"
    },
    {
      "en": "It is hot",
      "es": "hace calor"
    },
    {
      "en": "It is very hot",
      "es": "hace mucho calor"
    },
    {
      "en": "It is cool",
      "es": "hace fresco"
    },
    {
      "en": "It is windy",
      "es": "hace viento"
    },
    {
      "en": "It is sunny",
      "es": "hace sol"
    },
    {
      "en": "It is cloudy",
      "es": "esta nublado"
    },
    {
      "en": "It is very cloudy",
      "es": "esta muy nublado"
    },
    {
      "en": "It is overcast",
      "es": "esta cubierto"
    },
    {
      "en": "It is clear",
      "es": "esta despejado"
    },
    {
      "en": "It is raining",
      "es": "llueve"
    },
    {
      "en": "It rains a lot",
      "es": "llueve mucho"
    },
    {
      "en": "It is snowing",
      "es": "nieva"
    },
    {
      "en": "It snows a lot",
      "es": "nieva mucho"
    },
    {
      "en": "There is fog",
      "es": "hay niebla"
    },
    {
      "en": "There is mist",
      "es": "hay neblina"
    },
    {
      "en": "There is a storm",
      "es": "hay tormenta"
    },
    {
      "en": "There is thunder and lightning",
      "es": "hay truenos y relampagos"
    },
    {
      "en": "There is hail",
      "es": "hay granizo"
    },
    {
      "en": "There are showers",
      "es": "hay chubascos"
    },
    {
      "en": "It is humid",
      "es": "hay humedad"
    },
    {
      "en": "The weather is good",
      "es": "hace buen tiempo"
    },
    {
      "en": "The weather is bad",
      "es": "hace mal tiempo"
    },
    {
      "en": "It is drizzling",
      "es": "llovizna"
    },
    {
      "en": "It is freezing",
      "es": "esta helando"
    },
    {
      "en": "It is mild",
      "es": "el clima es templado"
    },
    {
      "en": "It is dry",
      "es": "esta seco"
    },
    {
      "en": "It is wet",
      "es": "esta humedo"
    },
    {
      "en": "What is the weather like?",
      "es": "que tiempo hace"
    }
  ],
  "Past": [
    {
      "en": "Yesterday it was cold",
      "es": "ayer hizo frio"
    },
    {
      "en": "Yesterday it was hot",
      "es": "ayer hizo calor"
    },
    {
      "en": "Yesterday it was windy",
      "es": "ayer hizo viento"
    },
    {
      "en": "Yesterday it was sunny",
      "es": "ayer hizo sol"
    },
    {
      "en": "Yesterday it was cloudy",
      "es": "ayer estuvo nublado"
    },
    {
      "en": "Yesterday it was overcast",
      "es": "ayer estuvo cubierto"
    },
    {
      "en": "Yesterday it rained",
      "es": "ayer llovio"
    },
    {
      "en": "Yesterday it snowed",
      "es": "ayer nevo"
    },
    {
      "en": "Yesterday there was fog",
      "es": "ayer hubo niebla"
    },
    {
      "en": "Yesterday there was a storm",
      "es": "ayer hubo tormenta"
    },
    {
      "en": "Yesterday there was hail",
      "es": "ayer hubo granizo"
    },
    {
      "en": "The temperature was ten degrees",
      "es": "la temperatura fue de diez grados"
    },
    {
      "en": "The weather was good",
      "es": "hizo buen tiempo"
    },
    {
      "en": "The weather was bad",
      "es": "hizo mal tiempo"
    },
    {
      "en": "It rained a lot",
      "es": "llovio mucho"
    },
    {
      "en": "It snowed a lot",
      "es": "nevo mucho"
    },
    {
      "en": "It was humid",
      "es": "hubo humedad"
    },
    {
      "en": "It was mild",
      "es": "el clima fue templado"
    },
    {
      "en": "It was dry",
      "es": "estuvo seco"
    },
    {
      "en": "It was wet",
      "es": "estuvo humedo"
    }
  ],
  "Future": [
    {
      "en": "Tomorrow it will be cold",
      "es": "manana hara frio"
    },
    {
      "en": "Tomorrow it will be hot",
      "es": "manana hara calor"
    },
    {
      "en": "Tomorrow it will be windy",
      "es": "manana hara viento"
    },
    {
      "en": "Tomorrow it will be sunny",
      "es": "manana hara sol"
    },
    {
      "en": "Tomorrow it will be cloudy",
      "es": "manana estara nublado"
    },
    {
      "en": "Tomorrow it will be overcast",
      "es": "manana estara cubierto"
    },
    {
      "en": "Tomorrow it will rain",
      "es": "manana llovera"
    },
    {
      "en": "Tomorrow it will snow",
      "es": "manana nevara"
    },
    {
      "en": "Tomorrow there will be fog",
      "es": "manana habra niebla"
    },
    {
      "en": "Tomorrow there will be a storm",
      "es": "manana habra tormenta"
    },
    {
      "en": "Tomorrow there will be hail",
      "es": "manana habra granizo"
    },
    {
      "en": "The temperature will be ten degrees",
      "es": "la temperatura sera de diez grados"
    },
    {
      "en": "The weather will be good",
      "es": "hara buen tiempo"
    },
    {
      "en": "The weather will be bad",
      "es": "hara mal tiempo"
    },
    {
      "en": "It will rain a lot",
      "es": "llovera mucho"
    },
    {
      "en": "It will snow a lot",
      "es": "nevara mucho"
    },
    {
      "en": "It will be humid",
      "es": "habra humedad"
    },
    {
      "en": "It will be mild",
      "es": "el clima sera templado"
    },
    {
      "en": "It will be dry",
      "es": "estara seco"
    },
    {
      "en": "It will be wet",
      "es": "estara humedo"
    }
  ]
};
;

let currentTense = "Present";
let currentLevel = 1;
let unlockedLevels = { Present: 1, Past: 1, Future: 1 };
let gameVerbs = [];
let startTime, timerInterval;

const tenseButtons = document.querySelectorAll(".tense-button");
const levelList = document.getElementById("level-list");
const gameContainer = document.getElementById("game");
const questionsContainer = document.getElementById("questions");
const resultsContainer = document.getElementById("results");

// ✅ TENSE BUTTONS now WORK
tenseButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    tenseButtons.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentTense = btn.dataset.tense;
    renderLevels();
  });
});

// ✅ RENDER LEVELS INITIALLY
renderLevels();

function renderLevels() {
  levelList.style.display = "flex";
  gameContainer.style.display = "none";
  levelList.innerHTML = "";

  for (let i = 1; i <= 10; i++) {
    const button = document.createElement("button");
    const bestTimeKey = `turbo_weather_bestTime_${currentTense}_Level${i}`;
    const bestTime = localStorage.getItem(bestTimeKey);
    const locked = i > unlockedLevels[currentTense];

    button.textContent = locked ? `Level ${i} 🔒` : `Level ${i}${bestTime ? ` - Best: ${bestTime}s` : ""}`;
    button.disabled = locked;

    button.addEventListener("click", () => {
      startGame(i);
    });

    levelList.appendChild(button);
  }
}

function startGame(level) {
  currentLevel = level;
  gameVerbs = shuffleArray(VERB_SETS[currentTense]).slice(0, 10);
  levelList.style.display = "none";
  gameContainer.style.display = "block";
  questionsContainer.innerHTML = "";
  resultsContainer.innerHTML = "";

  gameVerbs.forEach(verb => {
    const div = document.createElement("div");
    div.innerHTML = `<strong>${verb.en}</strong>: <input type="text" data-answer="${verb.es}">`;
    questionsContainer.appendChild(div);
  });

  startTimer();
}

function shuffleArray(array) {
  return array.sort(() => Math.random() - 0.5);
}

function startTimer() {
  startTime = Date.now();
  timerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    document.getElementById("timer").textContent = `Time: ${elapsed}s`;
  }, 1000);
}

function stopTimer() {
  clearInterval(timerInterval);
}

document.getElementById("submit").addEventListener("click", () => {
  stopTimer();
  const elapsed = Math.floor((Date.now() - startTime) / 1000);

  let penalty = 0;
  let correct = 0;

  document.querySelectorAll("#questions input").forEach(input => {
    if (input.value.trim().toLowerCase() === input.dataset.answer) {
      correct++;
      input.style.border = "2px solid green";
    } else {
      penalty += 30;
      input.style.border = "2px solid red";
    }
  });

  const totalTime = elapsed + penalty;
  resultsContainer.innerHTML = `<h3>Game Over!</h3><p>Correct: ${correct}/10</p><p>Time: ${elapsed}s + Penalty: ${penalty}s = <strong>${totalTime}s</strong></p><h4>Feedback:</h4>`;

  document.querySelectorAll("#questions input").forEach(input => {
    const correctAnswer = input.dataset.answer;
    const userAnswer = input.value.trim();
    if (userAnswer.toLowerCase() !== correctAnswer) {
      const feedback = document.createElement("p");
      feedback.innerHTML = `<strong>${input.previousSibling.textContent}</strong> → Correct answer: <span style='color: green;'>${correctAnswer}</span> | Your answer: <span style='color: red;'>${userAnswer || "(blank)"}</span>`;
      resultsContainer.appendChild(feedback);
    }
  });

  const bestTimeKey = `turbo_weather_bestTime_${currentTense}_Level${currentLevel}`;
  const savedBestTime = localStorage.getItem(bestTimeKey);
  if (!savedBestTime || totalTime < parseInt(savedBestTime)) {
    localStorage.setItem(bestTimeKey, totalTime);
    showArcadeCode('weather', totalTime);
  }

  if (totalTime <= levelUnlockTime(currentLevel)) {
    if (unlockedLevels[currentTense] < currentLevel + 1) {
      unlockedLevels[currentTense] = currentLevel + 1;
      const unlockMsg = document.createElement("p");
      unlockMsg.style.color = "blue";
      unlockMsg.innerHTML = `<strong>Level ${currentLevel + 1} Unlocked!</strong>`;
      resultsContainer.appendChild(unlockMsg);
    }
  }

  if (correct === 10) {
    const celebration = document.createElement("div");
    celebration.className = "perfect-celebration";
    celebration.textContent = "🎉 PERFECT GAME! 🎉";
    resultsContainer.prepend(celebration);

    setTimeout(() => {
      celebration.remove();
    }, 5000);
  }

  const tryAgainButton = document.createElement("button");
  tryAgainButton.textContent = "Try Again";
  tryAgainButton.className = "try-again";
  tryAgainButton.onclick = () => {
    startGame(currentLevel);
  };
  resultsContainer.appendChild(tryAgainButton);

  const backButton = document.createElement("button");
  backButton.textContent = "Back to Levels";
  backButton.id = "back-button";
  backButton.onclick = () => {
    renderLevels();
  };
  resultsContainer.appendChild(backButton);
});

function levelUnlockTime(level) {
  return 100 - (level - 1) * 5;
}